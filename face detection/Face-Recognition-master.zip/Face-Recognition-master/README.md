# Face-Recognition
Just read How_to_Run.txt file. You will understand how to train and run the face recognition project.
